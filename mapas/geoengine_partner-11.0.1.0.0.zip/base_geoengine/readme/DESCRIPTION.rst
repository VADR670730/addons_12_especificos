Geospatial support based on PostGIS add the ability of server to server
geojson to do geo CRUD and view definition.
