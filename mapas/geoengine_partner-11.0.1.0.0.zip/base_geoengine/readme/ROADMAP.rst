* Google layers have been removed as it was not working anyway.
* Switching from map to form view should be eased to open selected feature.
  It should work using `do_switch_view` and this probably requires to set `self.dataset.index`
* A good way to open a record from map should be done with double click.
  However selection handlers have difficulties to work nice with click events.
