# -*- coding: utf-8 -*-

from . import sale
from . import product
from . import invoice
from . import partner
