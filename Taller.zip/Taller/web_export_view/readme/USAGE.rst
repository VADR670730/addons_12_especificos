After you installed it, you'll find an additional link 'Export current view'
right on the sidebar. By clicking on it you'll get a XLS file contains
the same data of the tree view you are looking at, headers included.
