If we wanted to disallow users to use the features provided by this module, we
can add them to the group *Disallow Export View Data to Excel*.