* Henry Zhou (MAXodoo) <zhouhenry@live.com>
* Rodney <https://github.com/rv-clearcorp>
* Simone Orsi <simahawk@gmail.com>
* Lorenzo Battistini <lorenzo.battistini@agilebg.com>
* Stefan Rijnhart <stefan@therp.nl>
* Leonardo Pistone <leonardo.pistone@camptocamp.com>
* Jose Maria Bernet <josemaria.bernet@guadaltech.es>
* Alexandre Díaz <dev@redneboa.es>
* Valtteri Lattu <valtteri.lattu@tawasta.fi>
* `Tecnativa <https://www.tecnativa.com>`_:

  * David Vidal
  * Ernesto Tejeda
