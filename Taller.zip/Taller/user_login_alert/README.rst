User Login Alert v12
====================

This module will help to send the notification to users on successful login to his account.


Working
=======
if user is continuously using the same system the user will be notified only once. If he changes
 the browser or the OS from same system he will receive the mail.
If user logged from another system and if he come back to his original system, for the first time
he will receive the email
Configuration
=============
For the working of this module, the outgoing mail configuration has to be configured . The Email will be send
to Users related partners Email ID. If the Email ID for the related partner of the user is not given,
then the notification mail will not send.

Also install the "httpagentparser" python package, sudo pip install httpagentparser

Credits
=======
Cybrosys Techno Solutions
Author
	Niyas Raphy(v11)
	Akshay Babu(v12)
------
* Cybrosys Techno Solutions <https://www.cybrosys.com>
