# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

{
    'name': 'listado modelo 347',
    'summary': '347',
    'author': 'Pereira',
    'license': 'AGPL-3',
    'website': '',
    'category': 'Sales',
    'version': '12.0.1.0.0',
    'depends': [
        'account',
    ],
    'data': [
        'views/tax.xml',
    ],
    'installable': True,
    'aplication': True,
}
