.. image:: https://img.shields.io/badge/license-AGPL--3-blue.png
   :target: https://www.gnu.org/licenses/agpl
   :alt: License: AGPL-3

=======================
Sale Order Mass Confirm
=======================

This module allows a massive confirmation of sale orders.


Usage
=====

To use this module, you need to:

#. Open the tree view of sale orders.
#. Select the sale orders you want to confirm.
#. In the More menu select Confirm Sale Orders.
#. In the pop-up press Confirm.


Credits
=======

Contributors
------------

* Andrea Stirpe <a.stirpe@onestein.nl>
