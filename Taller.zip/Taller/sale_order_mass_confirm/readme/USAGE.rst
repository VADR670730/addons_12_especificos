To use this module, you need to:

#. Open the tree view of sale orders.
#. Select the sale orders you want to confirm.
#. In the More menu select Confirm Sale Orders.
#. In the pop-up press Confirm.
