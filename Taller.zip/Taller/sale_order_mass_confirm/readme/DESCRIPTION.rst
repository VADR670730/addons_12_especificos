This module allows a massive confirmation of sale orders.
