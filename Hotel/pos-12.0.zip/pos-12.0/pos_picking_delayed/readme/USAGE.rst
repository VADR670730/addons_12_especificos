* Use your Point of Sale as usual. When validating an order, the order will
  be in a different color until the job is executed

.. image:: /pos_picking_delayed/static/description/pos_order_tree.png
