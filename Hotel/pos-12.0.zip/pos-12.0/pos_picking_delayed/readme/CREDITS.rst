The development of this module has been financially supported by:

* GRAP, Groupement Régional Alimentaire de Proximité (www.grap.coop)
* Mind & Go, (https://mind-and-go.com/)
