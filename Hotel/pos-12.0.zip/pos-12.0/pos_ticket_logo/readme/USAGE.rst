#. Open a new PoS session.
#. Make an order and validate it.
#. You should see the company logo in the receipt preview.
