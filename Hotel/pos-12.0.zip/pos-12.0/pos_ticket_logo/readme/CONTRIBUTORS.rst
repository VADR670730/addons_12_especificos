* Endika Iglesias <endikaig@antiun.com>

* `Tecnativa <https://www.tecnativa.com>`_:

  * Antonio Espinosa
  * David Vidal
