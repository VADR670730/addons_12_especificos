[![Runbot Status](https://runbot.odoo-community.org/runbot/badge/flat/184/12.0.svg)](https://runbot.odoo-community.org/runbot/repo/github-com-oca-pos-184)
[![Build Status](https://travis-ci.org/OCA/pos.svg?branch=12.0)](https://travis-ci.org/OCA/pos)
[![Coverage Status](https://coveralls.io/repos/OCA/pos/badge.png?branch=12.0)](https://coveralls.io/r/OCA/pos?branch=12.0)

pos
===

Point of sale


