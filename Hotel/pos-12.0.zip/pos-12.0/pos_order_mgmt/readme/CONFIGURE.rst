To configure this module, you need to go to *Point of Sale > Configuration >
Point of Sale* and enable *Order Management*

.. image:: ../static/description/order-mgmt-config.png

#. Change *Maximum orders to load* to your desired amount (10 by default).
   Please note that the more you load, the more it will take to load
   them in the session opening. You can also set it to 0 and you'll just be
   able to load them from the order list screen.

#. Enable *Reprint orders* on if you want to be able to reprint past orders
   in that PoS.

#. Enable *Return orders* on if you want to be able to return past orders
   in that PoS.

#. Enable *Duplicate orders* on if you want to be able to return past orders
   in that PoS.
