# -*- coding: utf-8 -*-

import account_invoice
import product
import purchase_subscription
import res_partner
