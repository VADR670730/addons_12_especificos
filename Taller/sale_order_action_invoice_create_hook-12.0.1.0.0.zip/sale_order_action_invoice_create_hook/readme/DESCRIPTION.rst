This module adds hook points in sale_order.action_invoice_create() in order
to add more flexibility in the grouping parameters for the creation of
invoices and to give the possibility to take into account draft invoices.

Although the original code has been modified a bit, the logic has been
respected and the method still does exactly the same.
