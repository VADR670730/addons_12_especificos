* Jordi Ballester Alomar <jordi.ballester@eficent.com>
* Roser Garcia <roser.garcia@eficent.com>
* Raf Ven <raf.ven@dynapps.be>
